<?php 
$koneksi = mysqli_connect("localhost","root","","webkasir");
if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error());
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $nik = $_POST['nik'];
  $nama = $_POST['nama'];
  $jk = $_POST['jk'];
  $alamat = $_POST['alamat'];
  $telp = $_POST['telp'];


  $sql = "INSERT INTO datamember (nik, nama, jk, alamat, telp) VALUES ('$nik', '$nama', '$jk', '$alamat', '$telp')";
  if ($koneksi->query($sql) === TRUE ) {
    echo "<script>window.alert('Simpan data berhasil')</script>";
  }else{
    echo "Error: ". $sql . "<br>" . $koneksi->error;
  }
}
$koneksi->close();



?>
<div class="card mt-5">
	<div class="card-header">
		<h2>Data Member</h2>
	</div>

	<div class="card-body">
		<table class="table table-striped">
			<form method="post" action="">
				<tr>
					<td><label for="nik">NIK   :</label></td>
					<td><input type="number" minlength="14" maxlength="20" min="0" name="nik" class="form-control"></td>
				</tr>
				<tr>
					<td><label for="nama">Nama   :</label></td>
					<td><input type="text" name="nama" class="form-control" autocomplete="off"></td>
				</tr>
				<tr>
					<div class="form-check">
					<td><label for="jk">Jenis Kelamin   :</label></td>
					<td>
						<input type="radio" id="pria" name="jk" value="pria">Pria
						<input type="radio" id="wanita" name="jk" value="wanita" checked>Wanita
					</td>
					</div>
				</tr>
				<tr>
					<td><label for="alamat">Alamat   :</label></td>
					<td><textarea type="text" name="alamat" class="form-control" autocomplete="off"></textarea></td>
				</tr>
				<tr>
					<td><label for="telp">No. Telepon   :</label></td>
					<td><input type="number" minlength="0" maxlength="13" min="0" name="telp" class="form-control"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="Daftar" value="Simpan" class="btn btn-success">
						<input type="reset" name="reset" value="Batal" class="btn btn-danger"></td>
				</tr>

			</form>
		</table>
	</div>
</div>