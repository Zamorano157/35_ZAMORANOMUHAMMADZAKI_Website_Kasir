<?php 

$koneksi = mysqli_connect("localhost","root","","webkasir");
if ($koneksi->connect_error) {
  die("Koneksi gagal: " . $koneksi->connect_error());
}
if ($_SERVER['REQUEST_METHOD'] == "POST") {
  $username = $_POST['username'];
  $password = password_hash($_POST['password'], PASSWORD_DEFAULT);


  $sql = "INSERT INTO login (user, pass) VALUES ('$username', '$password')";
  if ($koneksi->query($sql) === TRUE ) {
    echo "<script>window.alert('Buat akun Berhasil')</script>";
  }else{
    echo "Error: ". $sql . "<br>" . $koneksi->error;
  }
}
$koneksi->close();
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Buat Akun</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>
<form method="post" action="">
      <div class="card mt-5">
  <div class="card-header py-3">
    <h3>Buat Akun</h3>
  </div>
  <div class="card-body">
<div class="form-floating mb-4">
  <input type="username" name="username" class="form-control" id="floatingInput" placeholder="username" autocomplete="off">
  <label for="floatingInput">Username</label>
</div>
<div class="form-floating">
  <input type="password" name="password" class="form-control" id="floatingPassword" placeholder="Password">
  <label for="floatingPassword">Password</label>
</div>
<button class="btn btn-primary mt-3" type="submit" name="Daftar" value="Daftar"><i class="bi bi-plus-lg"></i>
  Buat Akun
</button>

  </div>
</div>
</form>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>