# Kasir-Sederhana-byWZ

Berikut merupakan aplikasi kasir berbasis web dalam bentuk demo. Kedepannya akan dilakukan beberapa update pada aplikasi ini

Username = admin
password = admin

# Update v1.1.0
- seperate header, navbar, content, & footer in different file
- adding bootstrap datatables

Berikut tampilannya
- Dashboard
  ![Screenshot (186)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/232a1238-475a-42d5-a115-25fea570fa3d)
- Tabel Barang
  ![Screenshot (187)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/46fde7e3-f2f3-4ab4-bf4d-9ba058cc636e)
- Tabel Kategori
  ![Screenshot (188)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/35879b63-08ba-44df-840f-994d1684b937)
- Kasir
  ![Screenshot (189)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/ea1c9422-a6c4-4d46-86ba-62886f3a7907)
- Nota
  ![Screenshot (190)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/8ffede7f-0fed-4c2c-bdc9-e6a21210fd5e)



# V.1.0.1
- Dashboard
![Screenshot (158)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/2b37e7bb-ab29-4ade-9761-fdbb84a6d89b)
- Tabel Barang
![Screenshot (159)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/f813a36c-191a-4266-b448-1feb9b7194d9)
- Tabel Kategori
![Screenshot (160)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/3efa2b0d-3abe-4908-8034-2f1aaebc2b1b)
- Proses Kasir
![Screenshot (161)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/381d6395-97c9-4781-8bb5-82d5a5468696)
- Tabel Nota
![Screenshot (162)](https://github.com/Wz-00/Kasir-Sederhana-byWZ/assets/75877082/ccb8b684-d003-4a7a-b593-b4af43e5970a)
