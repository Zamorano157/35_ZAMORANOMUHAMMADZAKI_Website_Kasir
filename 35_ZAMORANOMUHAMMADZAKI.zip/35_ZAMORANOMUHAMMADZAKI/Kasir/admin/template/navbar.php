<div>
    <section class="p-4" id="main-content">
        <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
            <div class="container-fluid">
                <button class="btn btn-primary" id="button-toggle">
                    <i class="bi bi-menu-button"></i>
                </button>
                <a class="navbar-brand" href="index.php">
                    <img src="https://anwar.edukati.com/pluginfile.php/1/core_admin/logo/0x200/1703555122/logo%20png.png" alt="" width="15%" class="mr-2 ml-2">
                    <b id="name" class="mr-5">Web Kasir</b>
                </a>

                <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarNavDropdown">
                    <ul class="navbar-nav mt-auto">
                        
                    </ul>
                </div>
            </div>
        </nav>
        <br>