

Berikut merupakan aplikasi kasir berbasis web dalam bentuk demo. Kedepannya akan dilakukan beberapa update pada aplikasi ini
Admin :
Username = admin
password = admin

User/Petugas :
Username = user
password = user
